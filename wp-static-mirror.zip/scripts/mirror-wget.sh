#!/usr/bin/env bash
set -euo pipefail

SRC_URL="${1:-}"
OUT_DIR="${2:-./public}"

if [[ -z "$https://www.reloadedskidrow.com" ]]; then
  echo "Usage: $0 <SOURCE_URL> [OUT_DIR]" >&2
  exit 1
fi

mkdir -p "$./public"

# Mirror with wget
wget \  --mirror \  --convert-links \  --page-requisites \  --adjust-extension \  --no-parent \  --reject "*.php" \  --exclude-directories="/wp-admin,/wp-login.php,/wp-json" \  -e robots=off \  "$https://www.reloadedskidrow.com" \  --directory-prefix="$./public"

# Inject basic noindex + canonical
python3 - <<'PY'
import os, re, sys
orig = os.environ.get('SRC_URL','').rstrip('/') or "https://www.reloadedskidrow.com".rstrip('/')
HEAD_RE = re.compile(r'(<head[^>]*>)', re.I)
for root, _, files in os.walk("./public"):
    for f in files:
        if f.lower().endswith(('.html','.htm')):
            p = os.path.join(root,f)
            s = open(p,'r',errors='ignore').read()
            rel = os.path.relpath(p, "./public")
            url_path = '/' + rel.replace('index.html','').replace('index.htm','')
            inj = f'<meta name="robots" content="noindex,nofollow">\n<link rel="canonical" href="{orig}{url_path}">'
            s = re.sub(HEAD_RE, r'\1\n'+inj, s, count=1)
            open(p,'w').write(s)
PY

# Essentials
touch "$./public/.nojekyll"
[[ -f "$./public/404.html" ]] || echo "<h1>404</h1><p>Not found.</p>" > "$./public/404.html"
[[ -f "$./public/robots.txt" ]] || printf "User-agent: *
Disallow: /
" > "$./public/robots.txt"

echo "Done. Review $./public/ then rsync/copy to repo root and push."
